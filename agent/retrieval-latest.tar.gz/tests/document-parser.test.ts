import { describe, expect, it } from 'vitest';
import { buildEmbeddingText, deriveHeadingPath, parseDocumentForPreview } from '../src/services/document-parser';

function makeInput(text: string, splitOptions?: { min_clause_chars?: number; max_clause_chars?: number }) {
  return {
    file_name: 'sample.txt',
    file_mime: 'text/plain',
    content: Buffer.from(text, 'utf8'),
    split_options: splitOptions,
  };
}

describe('document parser', () => {
  it('keeps chapter as context and does not emit heading-only article chunks', async () => {
    const result = await parseDocumentForPreview(
      makeInput(['第一章 总则', '', '第十二条', '（一）适用范围。', '（二）管理要求。'].join('\n'))
    );

    expect(result.warnings).toEqual([]);
    expect(result.clauses).toHaveLength(2);
    expect(result.clauses[0].field_path).toBe('第一章 总则/第十二条/（一）');
    expect(result.clauses[0].heading_path).toEqual(['第一章 总则', '第十二条', '（一）']);
    expect(result.clauses[0].content).toBe('适用范围。');
    expect(result.clauses[1].field_path).toBe('第一章 总则/第十二条/（二）');
    expect(result.clauses.every((item) => item.content !== '第十二条')).toBe(true);
  });

  it('merges short body forward instead of emitting a tiny standalone chunk', async () => {
    const result = await parseDocumentForPreview(
      makeInput(
        ['第一章 总则', '', '第十二条 目的。', '', '第十三条 为了进一步规范管理，制定本办法。'].join('\n'),
        { min_clause_chars: 10, max_clause_chars: 200 }
      )
    );

    expect(result.clauses).toHaveLength(1);
    expect(result.clauses[0].field_path).toBe('第一章 总则/第十三条');
    expect(result.clauses[0].content).toContain('第十二条');
    expect(result.clauses[0].content).toContain('目的。');
    expect(result.clauses[0].content).toContain('为了进一步规范管理');
  });

  it('merges short sibling articles but preserves the merged title in content', async () => {
    const result = await parseDocumentForPreview(
      makeInput(
        ['第一章 总则', '', '第二条 本规定适用于集团直属单位。', '', '第三条 本规定的服务投诉包括热线、官网和来访。'].join('\n'),
        { min_clause_chars: 40, max_clause_chars: 200 }
      )
    );

    expect(result.warnings).toEqual([]);
    expect(result.clauses).toHaveLength(1);
    expect(result.clauses[0].field_path).toBe('第一章 总则/第三条');
    expect(result.clauses[0].content).toContain('第二条');
    expect(result.clauses[0].content).toContain('本规定适用于集团直属单位');
    expect(result.clauses[0].content).toContain('服务投诉包括热线、官网和来访');
  });

  it('falls back to paragraph chunks while preserving parent heading context', async () => {
    const result = await parseDocumentForPreview(
      makeInput(['第一章 总则', '', '适用范围说明。', '', '管理要求说明。'].join('\n'), {
        min_clause_chars: 20,
        max_clause_chars: 80,
      })
    );

    expect(result.warnings).toContain('AUTO_SPLIT_FALLBACK_PARAGRAPH');
    expect(result.clauses).toHaveLength(1);
    expect(result.clauses[0].field_path).toBe('第一章 总则');
    expect(result.clauses[0].heading_path).toEqual(['第一章 总则']);
    expect(result.clauses[0].content).toContain('适用范围说明。');
    expect(result.clauses[0].content).toContain('管理要求说明。');
  });

  it('derives heading path from stored field path and builds embedding text with context', () => {
    expect(deriveHeadingPath('第一章 总则/第十二条/（一）')).toEqual(['第一章 总则', '第十二条', '（一）']);
    expect(deriveHeadingPath('paragraph/1')).toEqual(['paragraph/1']);
    expect(buildEmbeddingText('制度标题', '第一章 总则/第十二条', '正文内容')).toBe(
      ['制度标题', '第一章 总则/第十二条', '正文内容'].join('\n')
    );
  });
});
