﻿# Vector KB Retrieval Service

## Features

- Field-level authorization with fixed access order: `driver < fleet < company < group`
- Silent filtering for unauthorized results in retrieval and document reads
- Document and clause CRUD with async index jobs
- Qdrant ANN retrieval + optional ClickHouse lexical fallback
- Worker for embedding and vector upsert/delete

## API Endpoints

- `POST /v1/retrieve`
- `POST /v1/documents`
- `PATCH /v1/documents/{docId}`
- `DELETE /v1/documents/{docId}?kb_id=...`
- `POST /v1/documents/{docId}/clauses:batchUpsert`
- `DELETE /v1/documents/{docId}/clauses/{clauseId}?kb_id=...`
- `POST /v1/reindex`
- `GET /v1/jobs/{jobId}`
- `GET /v1/documents?kb_id=...`
- `GET /v1/documents/{docId}?kb_id=...`

## Required Headers

- `X-Tenant-Id`
- `X-Caller-Level` (`driver|fleet|company|group`)
- `X-Caller-Id`
- `X-Caller-Company-Id` (required for company-level writes)

## Quick Start

1. Copy env file:

```bash
cp .env.example .env
```

2. Install and build:

```bash
npm ci
npm run build
```

3. Init ClickHouse schema:

```bash
npm run init:schema
```

4. Start API:

```bash
npm run start
```

5. Start worker in another shell:

```bash
npm run start:worker
```

## Docker

```bash
docker compose up -d --build
```

Initialize schema after containers are up:

```bash
docker exec -it kb-api node dist/init-schema.js
```

## Server Deployment (Reuse Existing ClickHouse)

Use `docker-compose.server.yml` on server if ClickHouse is already running outside this stack.

1. Set CK endpoint to host ClickHouse in `.env`:

```env
CK_DSN=http://default:@host.docker.internal:8123
```

2. Start:

```bash
docker compose -f docker-compose.server.yml up -d --build
docker exec -it kb-api node dist/init-schema.js
```

## Example: Create Document

```bash
curl -X POST http://127.0.0.1:8080/v1/documents \
  -H "Content-Type: application/json" \
  -H "X-Tenant-Id: bus-prod" \
  -H "X-Caller-Level: company" \
  -H "X-Caller-Id: op-001" \
  -H "X-Caller-Company-Id: first-branch" \
  -d '{
    "kb_id": "safety-kb",
    "title": "事故调查规范",
    "default_min_level": "company",
    "clauses": [
      {
        "field_path": "section_1.event",
        "content": "发生事故后5分钟内完成口头上报。",
        "tags": ["事故", "上报"]
      }
    ]
  }'
```

## Example: Retrieve

```bash
curl -X POST http://127.0.0.1:8080/v1/retrieve \
  -H "Content-Type: application/json" \
  -H "X-Tenant-Id: bus-prod" \
  -H "X-Caller-Level: fleet" \
  -H "X-Caller-Id: captain-001" \
  -d '{
    "kb_id": "safety-kb",
    "query": "事故后多久上报",
    "top_k": 5
  }'
```

## Edge Integration

Keep current edge pipeline and only replace retrieval call:

- Set `RAG_RETRIEVAL_URL=http://<kb-api-host>:8080/v1/retrieve`
- Forward caller headers from edge to KB API
- Keep prompt assembly and LLM invocation unchanged
