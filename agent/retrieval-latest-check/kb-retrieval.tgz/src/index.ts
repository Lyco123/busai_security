import Fastify from 'fastify';
import { ZodError } from 'zod';
import { config } from './config';
import { resolveCallerContext } from './auth';
import { ApiError } from './utils/errors';
import {
  batchUpsertClauses,
  createDocument,
  deleteClause,
  deleteDocument,
  getDocument,
  getJob,
  listDocuments,
  patchDocument,
  retrieve,
  triggerReindex,
} from './services/kb-service';
import { ensureQdrantCollection } from './services/qdrant';

const app = Fastify({
  logger: {
    level: config.logLevel,
  },
});

app.setErrorHandler((error, _request, reply) => {
  if (error instanceof ApiError) {
    return reply.status(error.statusCode).send({
      success: false,
      error: {
        code: error.code,
        message: error.message,
      },
    });
  }
  if (error instanceof ZodError) {
    return reply.status(400).send({
      success: false,
      error: {
        code: 'INVALID_PAYLOAD',
        message: error.issues.map((item) => item.message).join('; '),
      },
    });
  }
  app.log.error({ err: error }, 'Unhandled request error');
  return reply.status(500).send({
    success: false,
    error: {
      code: 'INTERNAL_ERROR',
      message: 'Internal server error',
    },
  });
});

app.get('/health', async () => ({
  status: 'ok',
  timestamp: new Date().toISOString(),
}));

app.post('/v1/retrieve', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const result = await retrieve(caller, request.body);
  return reply.status(200).send({
    success: true,
    ...result,
  });
});

app.post('/v1/documents', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const result = await createDocument(caller, request.body);
  return reply.status(result.statusCode).send({
    success: true,
    data: result.data,
  });
});

app.patch('/v1/documents/:docId', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const params = request.params as { docId: string };
  const result = await patchDocument(caller, params.docId, request.body);
  return reply.status(result.statusCode).send({
    success: true,
    data: result.data,
  });
});

app.delete('/v1/documents/:docId', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const params = request.params as { docId: string };
  const query = request.query as { kb_id?: string };
  if (!query.kb_id) {
    throw new ApiError(400, 'MISSING_KB_ID', 'Query kb_id is required');
  }
  const result = await deleteDocument(caller, query.kb_id, params.docId);
  return reply.status(result.statusCode).send({
    success: true,
    data: result.data,
  });
});

app.post('/v1/documents/:docId/clauses:batchUpsert', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const params = request.params as { docId: string };
  const result = await batchUpsertClauses(caller, params.docId, request.body);
  return reply.status(result.statusCode).send({
    success: true,
    data: result.data,
  });
});

app.delete('/v1/documents/:docId/clauses/:clauseId', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const params = request.params as { docId: string; clauseId: string };
  const query = request.query as { kb_id?: string };
  if (!query.kb_id) {
    throw new ApiError(400, 'MISSING_KB_ID', 'Query kb_id is required');
  }
  const result = await deleteClause(caller, query.kb_id, params.docId, params.clauseId);
  return reply.status(result.statusCode).send({
    success: true,
    data: result.data,
  });
});

app.post('/v1/reindex', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const result = await triggerReindex(caller, request.body);
  return reply.status(result.statusCode).send({
    success: true,
    data: result.data,
  });
});

app.get('/v1/jobs/:jobId', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const params = request.params as { jobId: string };
  const result = await getJob(caller, params.jobId);
  return reply.status(200).send({
    success: true,
    ...result,
  });
});

app.get('/v1/documents', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const query = request.query as { kb_id?: string; limit?: string; offset?: string };
  if (!query.kb_id) {
    throw new ApiError(400, 'MISSING_KB_ID', 'Query kb_id is required');
  }
  const rawLimit = Number(query.limit ?? 20);
  const rawOffset = Number(query.offset ?? 0);
  const limit = Number.isFinite(rawLimit) ? Math.min(100, Math.max(1, Math.floor(rawLimit))) : 20;
  const offset = Number.isFinite(rawOffset) ? Math.max(0, Math.floor(rawOffset)) : 0;
  const result = await listDocuments(caller, query.kb_id, limit, offset);
  return reply.status(200).send({
    success: true,
    ...result,
  });
});

app.get('/v1/documents/:docId', async (request, reply) => {
  const caller = resolveCallerContext(request);
  const params = request.params as { docId: string };
  const query = request.query as { kb_id?: string; include_clauses?: string };
  if (!query.kb_id) {
    throw new ApiError(400, 'MISSING_KB_ID', 'Query kb_id is required');
  }
  const includeClauses = query.include_clauses !== 'false';
  const result = await getDocument(caller, query.kb_id, params.docId, includeClauses);
  return reply.status(200).send({
    success: true,
    ...result,
  });
});

async function bootstrap() {
  await ensureQdrantCollection();
  await app.listen({
    port: config.kbApiPort,
    host: '0.0.0.0',
  });
  app.log.info(`KB API started on port ${config.kbApiPort}`);
}

bootstrap().catch((error) => {
  app.log.error({ err: error }, 'Failed to start KB API');
  process.exit(1);
});
