import { createClient, type ClickHouseClient, type CommandResult } from '@clickhouse/client';
import { config } from '../config';

export class ClickHouseGateway {
  private readonly client: ClickHouseClient;

  constructor() {
    this.client = createClient({
      url: config.ckDsn,
      request_timeout: config.requestTimeoutMs,
      max_open_connections: 10,
    });
  }

  async selectRows<T>(query: string, params?: Record<string, unknown>): Promise<T[]> {
    const result = await this.client.query({
      query,
      query_params: params,
      format: 'JSONEachRow',
    });
    return result.json<T>();
  }

  async selectOne<T>(query: string, params?: Record<string, unknown>): Promise<T | null> {
    const rows = await this.selectRows<T>(query, params);
    return rows[0] ?? null;
  }

  async command(query: string, params?: Record<string, unknown>): Promise<CommandResult> {
    return this.client.command({
      query,
      query_params: params,
    });
  }

  async insert<T extends object>(table: string, rows: T[]): Promise<void> {
    if (!rows.length) return;
    await this.client.insert({
      table,
      values: rows,
      format: 'JSONEachRow',
    });
  }
}

export const clickhouseGateway = new ClickHouseGateway();
